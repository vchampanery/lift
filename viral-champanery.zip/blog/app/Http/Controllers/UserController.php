<?php
 
namespace App\Http\Controllers;

use Illuminate\Support\Facades\Config;

class UserController extends Controller
{
    public $FORMATE = 'D,M jS Y';

    /***
     * Return only week Payday
     */
    public function checkWeekPayday($lastDay,$yearStart){
        $payD = null;
        if(substr($lastDay, 0, 3) == 'Sat'){
            $payD = $this->FormatDate(strtotime ('-1 day', $yearStart),$this->FORMATE);
        }elseif(substr($lastDay, 0, 3) == 'Sun'){
            $payD = $this->FormatDate(strtotime ('-2 day', $yearStart),$this->FORMATE);
        }else{
            $payD = $lastDay;
        }
        return $payD;
    }
    
    /***
     * Return only week Bonusday
     */
    public function checkWeekBonusday($bounceDay,$bounceTime){
        $bonusD = null;
        if(substr($bounceDay, 0, 3) == 'Sat'){
            $bonusD = $this->FormatDate(strtotime ('+3 day', $bounceTime),$this->FORMATE);
        }elseif(substr($bounceDay, 0, 3) == 'Sun'){
            $bonusD = $this->FormatDate(strtotime ('+2 day', $bounceTime),$this->FORMATE);
        }else{
            $bonusD= $bounceDay;
        }
        return $bonusD;
    }
    /***
     * Check date with weekend
     */
    public function findIfweekend($lastDay,$yearStart,$bounceDay,$bounceTime){
        $returnAry =[];
        $returnAry['PaymentDate'] = $this->checkWeekPayday($lastDay,$yearStart);
        $returnAry['Bonusday'] = $this->checkWeekBonusday($bounceDay,$bounceTime);
        return $returnAry;
    }
    /**
     * Set header in csv file
     */
    public function getHeader($fileName)
    {
        return  array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0"
        );
    }
    /***
     * helper functoin for formate date 
     */
    public function FormatDate($date, $format){

        return date($format, $date);
    }
    /**
     * Show the profile for a given user.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function show()
    {
        $fileName = 'tasks-'.time().'.csv';

        $headers = $this->getHeader($fileName);

        $columns = array('Month', 'Payment Date','Bonus Day',);

        $callback = function() use( $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);
            for ($mnth=1; $mnth<=12; $mnth++) {
                $month = date('F', mktime(0,0,0,$mnth, 1, date('Y')));
                $yearStart = strtotime('last day of '.$month, time());
                $lastDay = $this->FormatDate($yearStart,$this->FORMATE);
                $row['Month']  = $month;
                $preMonth= ($mnth==12)?1:$mnth+1;
                $curtime = ($mnth==12)? strtotime("+11 days", strtotime("first day of next year")) :
                                    strtotime(date("Y-".$preMonth."-12 H:i:s"));
                $urtime = $this->FormatDate($curtime,$this->FORMATE);
                $row1    = $this->findIfweekend($lastDay,$yearStart,$urtime,$curtime);
                $row['PaymentDate']    =$row1['PaymentDate'];
                $row['Bonusday']    =$row1['Bonusday'];
                $yearStart = strtotime('second monday  of '.$month, time());
                $lastDay = $this->FormatDate($yearStart,$this->FORMATE);

                fputcsv($file, array($row['Month'], $row['PaymentDate'],$row['Bonusday']));
            }

            fclose($file);
        };
        return response()->stream($callback, 200, $headers);
    }
}